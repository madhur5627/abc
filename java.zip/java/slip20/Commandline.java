package slip20;
import java.util.*;
public class Commandline {
    public static void main(String args[])
    {
        ArrayList<String> list=new ArrayList<>();
        for(String s:args)
        list.add(s);

        Iterator i=list.iterator();
        while(i.hasNext())
        System.out.println(i.next());

    }
    
}
