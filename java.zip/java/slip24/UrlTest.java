package slip24;
import java.net.*;
import java.util.*;
import java.io.*;
public class UrlTest {
    public static void main(String[] args)throws IOException 
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter URL");
        String url=sc.nextLine();
        URL u=new URL(url);
        URLConnection uc=u.openConnection();
        System.out.println("get date :"+uc.getDate());
        System.out.println("get content type :"+uc.getContentType());
        System.out.println("get expiry :"+uc.getExpiration());
        System.out.println("get last modified date :"+uc.getLastModified());

        int len=uc.getContentLength();
        InputStream i=uc.getInputStream();
        byte[] buffer = new byte[len];
        i.read(buffer);
        System.out.println(new String(buffer));
        i.close();
    }
}
