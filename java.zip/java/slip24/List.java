package slip24;
import java.util.*;
public class List {
    public static void main(String args[])
    {
        LinkedList<Integer> list=new LinkedList<>();
        Scanner sc=new Scanner(System.in);
        System.out.println("how many integers :");
        int n=sc.nextInt();
        for(int i=0;i<n;i++)
        {
            System.out.println("enter number");
            list.add(sc.nextInt());
        }

        System.out.println("enter element to enter at first position");
        int key=sc.nextInt();
        list.add(0,key);
        System.out.println(list);
        System.out.println("size of list is :"+list.size());

    }
    
}
