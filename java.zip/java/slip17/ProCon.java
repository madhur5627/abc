package slip17;

public class ProCon implements Runnable{
    private int n;
    Thread p,c;
    public static void main(String args[])
    {
       new ProCon();
    }
    public ProCon()
    {
        p=new Thread(this);
        c=new Thread(this);
        p.start();
        c.start();
    }
    
    public void run()
    {
            for(int i=0;i<5;i++)
            {
                if(Thread.currentThread()==p)
                {
                synchronized(this){
                n+=10;
                System.out.println("items produced are :"+n);
                if(n==50){
                    try{
                    notifyAll();
                    wait();
                    }catch(InterruptedException e){}
                }
                 }
                }
                if(Thread.currentThread()==c)
                {
                    synchronized(this){
                        n-=10;
                        System.out.println("items remain after consuming :"+n);
                        if(n==0){
                            try{
                            notifyAll();
                            wait();
                        }catch(InterruptedException e){}
                    }
                    }
                }
            }

        }
       
    }
    
