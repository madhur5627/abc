package slip17;
import java.util.*;
public class List {
    public static void main(String args[])
    {
        ArrayList<String> list=new ArrayList<>();
        Scanner sc=new Scanner(System.in);
        System.out.println("how many cities :");
        int n=sc.nextInt();

        for(int i=0;i<n;i++)
        {
            System.out.println("enter city");
            list.add(sc.next());
        }
        System.out.println(list);
        System.out.println("enter index to be eliminated");
        int index=sc.nextInt();

        list.remove(index);
        System.out.println("new list :"+list);

    }
    
}
