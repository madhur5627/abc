package slip4;
import javax.swing.*;
import java.awt.*;
public class Blink extends JFrame implements Runnable {
    Thread t;
    String s;
    public Blink()
    {
        t=new Thread(this);
        s=new String("welcome");
        setSize(300,300);
        setVisible(true);
        t.start();
    }
    public void paint(Graphics g)
    {
        g.setColor(Color.red);
        g.fillRect(0,0,300,300);
        g.setColor(Color.black);
        g.drawString(s,150,150);
    }
    public void run()
    {
        try{
        for(int i=1;i>0;i++)
        {
            if(s=="")
            s="welcome";
            else
            s="";
            repaint();
            Thread.sleep(150);
        }
        }
        catch(InterruptedException e){}
    }
    public static void main(String args[])
    {
        Blink b=new Blink();
    }   
}
