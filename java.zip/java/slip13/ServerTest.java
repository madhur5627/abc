package slip13;

import java.io.*;
import java.net.*;
public class ServerTest {
    private Socket con;
    private ServerSocket server;
    DataInputStream receivedMsg;
    public ServerTest() {
        try {
            server = new ServerSocket(5000, 1, InetAddress.getLocalHost());
        } catch (IOException e) {}
    }
    public void talk() {
        try {
            con = server.accept();
            receivedMsg = new DataInputStream(con.getInputStream());
            String msg;
            while (true) {
                msg = receivedMsg.readUTF();
                if (msg.equals("EXIT")) {
                    System.out.println("Received exit command, shutting down server");
                    break;
                } else 
                    System.out.println(msg);
            }
            con.close();
        } catch (IOException e) {}
    }
    public static void main(String args[]) {
        ServerTest t = new ServerTest();
        t.talk();
    }
}