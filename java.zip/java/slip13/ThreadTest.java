package slip13;

public class ThreadTest extends Thread{
    public static void main(String args[])
    {
        ThreadTest t=new ThreadTest();
        System.out.println(t.getName());
        System.out.println(t.getPriority());

        System.out.println("thread alive status : "+t.isAlive());

        t.setName("first");
        t.start();
        System.out.println("new thread status : "+t.isAlive());
        System.out.println("new name: "+t.getName());
        

    }
    
}
