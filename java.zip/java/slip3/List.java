package slip3;


import java.util.*;
public class List {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        LinkedList<String> list=new LinkedList<>();

        System.out.println("how many strings :");
        int n=sc.nextInt();

        for(int i=0;i<n;i++)
        {
            System.out.println("enter string :");
            list.add(sc.next());
        }

        System.out.println("enter String you want to add at the end :");
        list.add(n,sc.next());
        System.out.println(list);

        System.out.println("reverse order list :");
        Iterator i=list.descendingIterator();
        while(i.hasNext())
        System.out.println(i.next());
    }
}
