package slip16;
import java.net.*;
import java.io.*;
import java.util.*;
public class UrlTest {
    public static void main(String args[])throws IOException
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter URL :");//enter html program path
        String url=sc.nextLine();
        URL u=new URL(url);

        URLConnection uc=u.openConnection();
        System.out.println("date of creation :"+uc.getDate());
        System.out.println("content type :"+uc.getContentType());
        System.out.println("last modified date :"+uc.getLastModified());
    }   
}
