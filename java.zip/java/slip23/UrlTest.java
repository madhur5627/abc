package slip23;
import java.net.*;
import java.util.*;
import java.io.*;
public class UrlTest {
    public static void main(String args[])throws MalformedURLException,IOException
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter url :");
        String url=sc.nextLine();
        URL u=new URL(url);
        System.out.println("protocol :"+u.getProtocol());
        System.out.println("host name :"+u.getHost());
        System.out.println("port :"+u.getPort());
        System.out.println("file name :"+u.getFile());
    }
}
