package slip23;
import java.sql.*;
public class DB {
    private Connection con;
    private PreparedStatement pstmt;
    public void getConnection()
    {
        try{
            Class.forName("org.postgresql.Driver");
            String url="jdbc:postgresql://192.168.5.200:5432/bcaty43";
            con=DriverManager.getConnection(url,"bcaty43","");
        }catch(ClassNotFoundException e){}
        catch(SQLException e){}
    }
    public void delete(int num){
        try{
            String query="delete from employee where eno=?";
            pstmt=con.prepareStatement(query);
            pstmt.setInt(1,num);
            int ans=pstmt.executeUpdate();
            if(ans==0)
            System.out.println("deletion failed");
            else
            System.out.println("deletion successful");
            con.close();
        }catch(SQLException e){}
    }
    public static void main(String[] args) {
        int num=Integer.parseInt(args[0]);
        DB obj=new DB();
        obj.getConnection();
        obj.delete(num);
    }
}