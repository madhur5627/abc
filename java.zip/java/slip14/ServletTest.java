package slip14;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.Date;
public class ServletTest extends HttpServlet{
    public void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException
    {
        resp.setContentType("text/html");
        PrintWriter out=resp.getWriter();

        out.println("IP address is :"+req.getRemoteAddr());
        out.println("browser type is :"+req.getHeader("User-Agent"));
        Date d=new Date();
        out.println("date and time is :"+d.toString());
    }
    
}
