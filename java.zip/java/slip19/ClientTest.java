package slip19;
import java.net.*;
import java.io.*;
import java.util.*;
public class ClientTest {
    private Socket con;
    private DataOutputStream sendmsg;
    public ClientTest()
    {  try{
            con=new Socket(InetAddress.getLocalHost(),5000);
            sendmsg=new DataOutputStream(con.getOutputStream());
        }
        catch(IOException e){}
    }
    public void talk()
    {  
        try{
        Scanner sc=new Scanner(System.in);
         System.out.println("enter file name:");
                String msg=sc.nextLine();
                sendmsg.writeUTF(msg);
        }
        catch(IOException e){}
    }
    public static void main(String args[])
    {
        ClientTest t=new ClientTest();
        t.talk();
    }   
}
