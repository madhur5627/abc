package slip19;
import java.net.*;
import java.util.Scanner;
import java.io.*;
public class ServerTest {
    private Socket con;
    private ServerSocket server;
    private DataInputStream receivedmsg;
    public ServerTest()
    {
        try{
            server=new ServerSocket(5000,1,InetAddress.getLocalHost());
        }catch(IOException e){}
    }
    public void talk()
    {
        try{
            con=server.accept();
            receivedmsg=new DataInputStream(con.getInputStream());
            String msg=receivedmsg.readUTF();
           File file=new File(msg);
           if(file.exists())
           {
            Scanner sc=new Scanner(file);
            while(sc.hasNextLine())
                System.out.println(sc.nextLine());
           }
           else
           System.out.println("file not found");
            con.close();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());    
        }
        
    }
    public static void main(String[] args) {
        ServerTest t=new ServerTest();
        t.talk();
    }
    
}
