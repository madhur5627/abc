package slip19;
import java.util.*;
public class Vowel extends Thread {
    private static String str;
    public static void main(String args[])
    {
        Vowel t=new Vowel();
        Scanner sc=new Scanner(System.in);
        str=sc.next();
        t.start();
    }

    public void run()
    {
        try{
        for(int i=0;i<str.length();i++)
        {
            if(str.charAt(i)=='A'||str.charAt(i)=='E'||str.charAt(i)=='I'||str.charAt(i)=='O'||str.charAt(i)=='U'||
            str.charAt(i)=='a'||str.charAt(i)=='e'||str.charAt(i)=='i'||str.charAt(i)=='o'||str.charAt(i)=='u')
            System.out.println(str.charAt(i));
            Thread.sleep(3000);
        }
    }
    catch(InterruptedException e){}
    }
}
