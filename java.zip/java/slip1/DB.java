package slip1;
import java.sql.*;
import java.util.*;
public class DB {
    Connection con;
    PreparedStatement pstmt;

    public void getConnection()
    {
        try{
            Class.forName("org.postgresql.Driver");
            String url="jdbc:postgresql://192.168.5.200:5432/bcaty43";
            con=DriverManager.getConnection(url,"bcaty43","");
        }
        catch(ClassNotFoundException e){}
        catch(SQLException e){}
    }

    public void insertData(int num,String name,String dsgn,float sal)
    {
        try{
            String query="insert into Employee values(?,?,?,?)";
            pstmt=con.prepareStatement(query);
            pstmt.setInt(1,num);
            pstmt.setString(2,name);
            pstmt.setString(3,dsgn);
            pstmt.setFloat(4,sal);

            int ans=pstmt.executeUpdate();

            if(ans==0)
            System.out.println("insertion failed");
            else
            System.out.println("insetion successful");
            pstmt.close();
            con.close();
        }
        catch(SQLException e){}
    }
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        DB obj=new DB();
        obj.getConnection();
        System.out.println("enter number,name,designation and salary");
        int num=sc.nextInt();
        String name=sc.next();
        String dsgn=sc.next();
        float sal=sc.nextFloat();
        obj.insertData(num,name,dsgn,sal);
    }
}
