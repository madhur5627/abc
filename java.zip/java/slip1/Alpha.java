package slip1;

public class Alpha extends Thread {
    public static void main(String args[])
    {
        Alpha t=new Alpha();
        t.start();
    }

    public void run()
    {
        try{
            for(int i=65;i<=90;i++)
            {
            char ch=(char)i;
            System.out.println(ch);
            Thread.sleep(200);
            }
        }
        catch(InterruptedException e){}
    }
    
}
