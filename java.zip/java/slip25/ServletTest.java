package slip25;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.Date;
public class ServletTest extends HttpServlet {
    public void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException
    {
        resp.setContentType("text/html");
        PrintWriter out=resp.getWriter();
        Date d=new Date();
        out.println("date and time is :"+d.toString());

        out.println("IP address :"+req.getRemoteAddr());
        out.println("browser type :"+req.getHeader("User-Agent"));

    }
    
}
