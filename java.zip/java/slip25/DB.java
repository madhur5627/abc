package slip25;
import java.sql.*;
public class DB {
    private Connection con;
    public void getConnection()
    {
        try{
        Class.forName("org.postgresql.Driver");
        System.out.println("Driver found");

        String url="jdbc:postgresql://192.168.5.200/bcaty43";
        con=DriverManager.getConnection(url,"bcaty43","");
        System.out.println("connection successful");
    }
    catch(ClassNotFoundException e){System.out.println(e);}
	catch(SQLException e){System.out.println(e);}
}
public static void main(String[] args) {
    DB obj=new DB();
    obj.getConnection();
}    
}
