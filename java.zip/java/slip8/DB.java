package slip8;
import java.sql.*;
public class DB {
    Connection con;
    ResultSet rs;
    Statement stmt;
    ResultSetMetaData rsmt;
    
    public void getConnection()
    {
        try{
            Class.forName("org.postgresql.Driver");
            String url="jdbc:postgresql://192.168.5.200:5432/bcaty43";
            con=DriverManager.getConnection(url,"bcaty43","");
        }
        catch(ClassNotFoundException e){}
        catch(SQLException e){}
    }

    public void display()
    {
        try{
            String query="select * from donor";
            stmt=con.createStatement();
            rs=stmt.executeQuery(query);

            rsmt=rs.getMetaData();
            int count=rsmt.getColumnCount();
            for(int i=1;i<=count;i++)
            {
                System.out.println("column name :"+rsmt.getColumnName(i));
                System.out.println("column type :"+rsmt.getColumnTypeName(i));
                System.out.println("column size :"+rsmt.getColumnDisplaySize(i));
            }
            rs.close();
            con.close();
        }
        catch(SQLException e){}
    }
    public void main()
    {
        DB obj=new DB();
        obj.getConnection();
        obj.display();
    }
}
