package slip5;
import java.util.*;
public class Set {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("how many integers to enter :");
        int n=sc.nextInt();
        TreeSet<Integer> set=new TreeSet<>();
        for(int i=0;i<n;i++)
        {
            System.out.println("enter number");
            set.add(sc.nextInt());
        }
        System.out.println(set);
        System.out.println("enter number to check :");
        int key=sc.nextInt();

        if(set.contains(key))
        System.out.println("present");
        else
        System.out.println("not present");

    }
    
}
