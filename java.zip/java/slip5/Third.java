package slip5;

public class Third extends Thread {
    private int n;
    public Third(int n)
    {
        this.n=n;
    }
    public void run()
    {
        System.out.println("cube of "+n+" is :"+n*n*n);
    }
}
