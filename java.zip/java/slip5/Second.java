package slip5;

public class Second extends Thread {
    private int n;
    public Second(int n)
    {
        this.n=n;
    }
    public void run()
    {
        System.out.println("square of "+n+" is :"+n*n);
    }
    
}
