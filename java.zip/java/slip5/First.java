package slip5;
import java.util.*;
public class First extends Thread {
    public static void main(String args[])
    {
        First f=new First();
        f.start();
    }
    public void run()
    {
        try{
            Random r=new Random();
        for(int i=0;i<10;i++){
            int n=r.nextInt(100);
            if(n%2==0)
            {
                Second s=new Second(n);
                s.start();
            }
            else{
                Third t=new Third(n);
                t.start();
            }
            Thread.sleep(1000);
            }
        }
        catch(InterruptedException e){}
        } 
}
