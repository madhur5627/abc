package slip12;

public class ThreadTest extends Thread {
    public static void main(String args[])
    {
        ThreadTest t=new ThreadTest();
        System.out.println("name of thread is :"+t.getName());
        System.out.println("original priority is :"+t.getPriority());
        t.setPriority(7);
        System.out.println("new priority :"+t.getPriority());
    }
    
}
