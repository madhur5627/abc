package slip12;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Visit extends HttpServlet {
    public void doGet(HttpServletRequest req,HttpServletResponse resp)throws IOException,ServletException
    {
        resp.setContentType("text/html");
        PrintWriter out=resp.getWriter();

        Cookie arr[]=req.getCookies();
        if(arr==null)
        {
            out.println("welcome for first time");
            Cookie c=new Cookie("count",1+"");
            resp.addCookie(c);
        }
        else
        {
            Cookie mycookie=arr[0];
            int cnt=Integer.parseInt(mycookie.getValue());
            cnt++;
            out.println("visited for : "+cnt+" times");
            Cookie c=new Cookie("count",cnt+"");
            resp.addCookie(c);
        }
    }
}
