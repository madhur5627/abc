package slip6;

public class Sleep extends Thread{
    public static void main(String args[])
    {
        Sleep t=new Sleep();
        System.out.println("default name of thread is :"+t.getName());
        t.setName("mythread");
        System.out.println("name of thread is :"+t.getName());
        t.start();
    }
    public void run()
    {
        try{
            for(int i=100;i>0;i--)
            {
                System.out.println(i);
                Thread.sleep(2000);
            }
        }
        catch(InterruptedException e){}
    }
    
}
