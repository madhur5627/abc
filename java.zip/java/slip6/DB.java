package slip6;
import java.sql.*;
public class DB {
    Connection con;
    Statement stmt;
    ResultSet rs;
    public void getConnection()
    {
        try{
            Class.forName("org.postgresql.Driver");
            String url="jdbc:postgresql://192.168.5.200:5432/bcaty43";
            con=DriverManager.getConnection(url,"bcaty43","");
        }
        catch(ClassNotFoundException e){}
        catch(SQLException e){}
    }
    public void display()
    {
        try{
            String query="select * from product";
            stmt=con.createStatement();
            rs=stmt.executeQuery(query);
            while(rs.next())
            {
                int id=rs.getInt("pid");
                String name=rs.getString("pname");
                float price=rs.getInt("price");
                System.out.println(id+" "+name+" "+price);
            }
            rs.close();
            stmt.close();
            con.close();
        }
        catch(SQLException e){}
    }
    public static void main(String args[])
    {
        DB obj=new DB();
        obj.getConnection();
        obj.display();
    }
}
