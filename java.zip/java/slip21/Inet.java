package slip21;
import java.net.*;
public class Inet {
    public static void main(String args[])throws UnknownHostException
    {
        InetAddress addr=InetAddress.getLocalHost();
        System.out.println("host name is :"+addr.getHostName());
        System.out.println("host name is :"+addr.getHostAddress());

    }
}
