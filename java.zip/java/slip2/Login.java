package slip2;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class Login extends HttpServlet {

    public void doPost(HttpServletRequest req,HttpServletResponse resp)throws IOException,ServletException
    {
        String name=req.getParameter("name");
        String password=req.getParameter("pass");

        resp.setContentType("text/html");
        PrintWriter out=resp.getWriter();

        if(name.equals("admin")&&password.equals("admin"))
        out.println("welcome");
        else
        out.println("error");

    }
}
