package slip2;

import java.util.*;
public class Set {
    public static void main(String args[])
    {
        HashSet<String> set=new HashSet<>();
        Scanner sc=new Scanner(System.in);

        System.out.println("how many names :");
        int n=sc.nextInt();
        for(int i=0;i<n;i++)
        {
            System.out.println("enter name :");
            set.add(sc.next());
        }
        TreeSet<String> sortedset=new TreeSet<>();
        for(String name:set)
        sortedset.add(name);

        System.out.println(sortedset);
    }    
}
