package slip11;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class Textfield extends JFrame implements Runnable,ActionListener {
    private JTextField txt;
    private JButton b;
    Thread t;
    public Textfield()
    {
        txt=new JTextField(10);
        b=new JButton("print");
        t=new Thread(this);
        setSize(300,300);
        setVisible(true);
        txt.setBounds(40,40,70,20);
        b.setBounds(50,50,70,50);
        add(txt);
        add(b);
        b.addActionListener(this);
    }
    public void actionPerformed( ActionEvent e)
    {
        t.start();
    }
    public void run()
    {
        for(int i=1;i<=100;i++)
        {
            try{
                txt.setText(i+"");
            Thread.sleep(1000);
            }
            catch(InterruptedException e){}
        }
    }
    public static void main(String args[])
    {
        new Textfield();
    }
}
