package slip10;
import java.sql.*;
public class DB {
    private Connection con;
    private ResultSet rs;
    private Statement stmt;
    private DatabaseMetaData dbmt;

    public void getConnection()
    {
        try{
            Class.forName("org.postgresql.Driver");
            String url="jdbc:postgresql://192.168.5.200:5432/bcaty43";
            con=DriverManager.getConnection(url,"bcaty43","");
        }
        catch(ClassNotFoundException e){}
        catch(SQLException e){}
    }
    public void display()
    {
        try{
            dbmt=con.getMetaData();
            System.out.println("product name :"+dbmt.getDatabaseProductName());
            System.out.println("product version :"+dbmt.getDatabaseProductVersion());
            System.out.println("product username :"+dbmt.getUserName());

            rs=dbmt.getTables(null,null,null,new String[]{"TABLE"});
            while(rs.next())
            System.out.println(rs.getString("TABLE_NAME"));

            rs.close();
            con.close();
        }
        catch(SQLException e){}
    }
    public static void main(String args[])
    {
        DB obj=new DB();
        obj.getConnection();
        obj.display();
    }
}
