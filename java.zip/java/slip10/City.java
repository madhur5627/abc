package slip10;

import java.util.HashMap;
import java.util.Scanner;
public class City {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        HashMap<String,Integer> map=new HashMap<>();
        System.out.println("how many cities to enter :");
        int n=sc.nextInt();

        for(int i=0;i<n;i++)
        {
            System.out.println("enter city and STD code");
            map.put(sc.next(),sc.nextInt());
        }
        System.out.println("enter city to search :");
        String city=sc.next();

        for(String key:map.keySet())
            if(key.equals(city))
            {
                System.out.println("city found and its code is :"+map.get(key));
                System.exit(0);
            }
            System.out.println("city not found");
    }
}
